﻿var sitemap = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,[_(c,d,e,f,g,h,i,[_(c,j,e,f,g,k),_(c,l,e,f,g,m),_(c,n,e,f,g,o),_(c,p,e,f,g,q)])]);}; 
var b="rootNodes",c="pageName",d="Home",e="type",f="Wireframe",g="url",h="Home.html",i="children",j="login",k="login.html",l="WatchVideo",m="WatchVideo.html",n="RestaurantSetUp",o="RestaurantSetUp.html",p="RestaurantSetUp2",q="RestaurantSetUp2.html";
return _creator();
})();
