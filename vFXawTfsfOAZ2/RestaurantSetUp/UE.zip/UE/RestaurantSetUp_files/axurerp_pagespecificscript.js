﻿for(var i = 0; i < 28; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});

$axure.eventManager.blur('u21', function(e) {

if (true) {

	SetPanelVisibility('u20','hidden','fade',300);

}
});

$axure.eventManager.blur('u23', function(e) {

if (true) {

	SetPanelVisibility('u22','hidden','fade',300);

}
});

$axure.eventManager.blur('u25', function(e) {

if (true) {

	SetPanelVisibility('u24','hidden','fade',300);

}
});

$axure.eventManager.blur('u27', function(e) {

if (true) {

	SetPanelVisibility('u26','hidden','fade',300);

}
});
gv_vAlignTable['u1'] = 'center';document.getElementById('u2_img').tabIndex = 0;

u2.style.cursor = 'pointer';
$axure.eventManager.click('u2', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('WatchVideo.html');

}
});
gv_vAlignTable['u3'] = 'center';document.getElementById('u4_img').tabIndex = 0;

u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('login.html');

}
});
gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u9'] = 'center';u10.tabIndex = 0;

u10.style.cursor = 'pointer';
$axure.eventManager.click('u10', function(e) {

if (true) {

	SetPanelVisibility('u11','','fade',300);

}
});
gv_vAlignTable['u10'] = 'top';
$axure.eventManager.blur('u12', function(e) {

if (true) {

	SetPanelVisibility('u11','hidden','fade',300);

}
});
u13.tabIndex = 0;

u13.style.cursor = 'pointer';
$axure.eventManager.click('u13', function(e) {

if (true) {

	SetPanelVisibility('u14','','fade',300);

}
});
gv_vAlignTable['u13'] = 'top';
$axure.eventManager.blur('u15', function(e) {

if (true) {

	SetPanelVisibility('u14','hidden','fade',300);

}
});
u16.tabIndex = 0;

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	SetPanelVisibility('u20','','fade',300);

}
});
gv_vAlignTable['u16'] = 'top';u17.tabIndex = 0;

u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	SetPanelVisibility('u22','','fade',300);

}
});
gv_vAlignTable['u17'] = 'top';u18.tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	SetPanelVisibility('u24','','fade',300);

}
});
gv_vAlignTable['u18'] = 'top';u19.tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	SetPanelVisibility('u26','','fade',300);

}
});
gv_vAlignTable['u19'] = 'top';